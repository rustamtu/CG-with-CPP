# Inputs for each of the Programs of 3rd Cycle

## Lineclip.C

Bottom left  20 20 <br>
Top right 240 240<br>
x1 30 <br>
y1 40 <br>
x2 300 <br>
y2 280 <br>

### 

## Polyclip.C

bottom left 10 10 <br>
 top right 200 200 <br>
 no of sides  3 <br>
 point 30 40 <br>
 point 2 150 100 <br>
 point 3 240 240 <br>
 
