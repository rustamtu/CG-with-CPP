# Computer-graphics

Different types of computer animation made using C language and OpenGL library as a part of the college coursework. 
