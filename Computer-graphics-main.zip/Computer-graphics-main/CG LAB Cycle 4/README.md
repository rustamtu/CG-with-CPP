## Fourth cycle of Computer Graphics Lab 

### List of Programs
<ol>
<li> Creating a Rainbow using Graphics Programming in C (rainbow.c).</li>
<li> Draw a moving car using computer graphics programming in C (move_car.C).</li>
<li> C smiling face animation (smiley.C).</li>
<li> Rocket propulsion (rocket.C).</li>
<li> C Program for Bouncing Ball Animation (BALLS.C).</li>
<li> Computer Graphics Program For Man Walking In the Rain In C Programming (ANIMATIO.C).</li>
<li> Animated clock in C (clock.C).</li>
 </ol>
